﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Searchmanage : MonoBehaviour
{
    [Header("搜索栏组件")]
    public TMP_InputField searchInput;    // 搜索输入框

    [Header("商品列表")]
    public Transform goodsContentParent;   // 商品列表的 Content（里面放着你摆好的所有商品）

    void Start()
    {
        if (searchInput != null)
        {
            // 监听输入框内容变化，实时搜索
            searchInput.onValueChanged.AddListener(OnSearchInputChanged);
        }
    }

    // 输入框内容改变时触发
    private void OnSearchInputChanged(string searchText)
    {
        PerformSearch(searchText);
    }

    // 执行搜索
    private void PerformSearch(string searchText)
    {
        if (string.IsNullOrEmpty(searchText))
        {
            // 搜索框为空，显示所有商品
            ShowAllGoods();
            return;
        }

        // 转换为小写，实现不区分大小写搜索
        string lowerSearchText = searchText.ToLower();
        int matchCount = 0;

        foreach (Transform goodsObj in goodsContentParent)
        {
            // 根据商品名称判断是否匹配
            bool isMatch = goodsObj.name.ToLower().Contains(lowerSearchText);
            goodsObj.gameObject.SetActive(isMatch);

            if (isMatch) matchCount++;
        }

        Debug.Log($"搜索：'{searchText}'，找到 {matchCount} 个商品");
    }

    // 显示所有商品
    private void ShowAllGoods()
    {
        foreach (Transform goodsObj in goodsContentParent)
        {
            goodsObj.gameObject.SetActive(true);
        }
    }
}