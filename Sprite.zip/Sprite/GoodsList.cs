using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoodsList : MonoBehaviour
{   
    public List<Goods> goodList = new List<Goods>();    //Ԥ�����Ʒ����

    public GameObject goodsPrefabInCart;                //�ڹ��ﳵ����ƷԤ����

    //public Transform goodsContentParent;                // ��Ʒ�б��� Content

    // Start is called before the first frame update
    void Start()
    {
        // ��ʼ����Ʒ����
        InitGoodsData();

    }

    void InitGoodsData()    //��ʼ����Ʒ
    {
        goodList.Add(new Goods("Book", 3));
        goodList.Add(new Goods("Scarf", 5.5f));
        goodList.Add(new Goods("Cup", 2.1f));
        goodList.Add(new Goods("Towel", 2.5f));
        goodList.Add(new Goods("Hanger", 0.5f));
        goodList.Add(new Goods("Apple", 1f));
        goodList.Add(new Goods("Grape", 1.8f));
        goodList.Add(new Goods("Banana", 2.2f));
    }
}
