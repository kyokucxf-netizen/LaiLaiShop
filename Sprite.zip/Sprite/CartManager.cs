using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using JetBrains.Annotations;
using UnityEngine.UI;


public class CartManager : MonoBehaviour
{
    public static CartManager Instance;
    private float total = 0f;

    private List<CartItem> cartItems = new List<CartItem>(); //���ﳵ����

    public Transform cartContentParent;     //���ﳵ�б�������
    public GameObject Good;                 //���ﳵ��ƷԤ����
    public TextMeshProUGUI totalPriceText;  //�ܼ���ʾ
    public TextMeshProUGUI cartBadgeText;   //���ﳵ�Ǳ�
    public Image cartBadeg_Image;           //���ﳵ�Ǳ�ͼ��
    public Image CartEmptyError_Image;      //���ﳵ����ʾ
    public Image AddressEmptyError_Image;   //��������ַΪ����ʾ
    public Image SuccessfulPurchase_Image;  //�ɹ�������ʾ


    public UIManage uiManage = new UIManage();

    // �洢����ʵ������ CartItemUI�����ڿ���ˢ�£�
    //private List<CartItemUI> cartItemUIs = new List<CartItemUI>();

    private void Awake()
    {
        if (Instance == null) 
        { 
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        cartBadgeText.gameObject.SetActive(false);
        cartBadeg_Image.gameObject.SetActive(false);
    }

    public void Start()
    {
        totalPriceText.text = "0";
    }

    public void AddToCart(Goods goods) 
    {
        CartItem existingItem = cartItems.Find(item => item.goods.name == goods.name);

        if (existingItem != null)
        {
            existingItem.quantity++;  //���У�������һ
            Debug.Log($"{goods.name} ���У�������һ������ {existingItem.quantity} ��");
        }
        else 
        {
            cartItems.Add(new CartItem(goods));
            Debug.Log($"���� {goods.name} �����ﳵ,���ۣ�{goods.price}");    //δ�У�����
            
        }

        RefreshCartUI();    //ˢ��UI
    }

    public void RemoveFromCart(Goods goods) 
    {
        CartItem existingItem = cartItems.Find(item => item.goods.name == goods.name);

        if (existingItem != null) 
        {
            existingItem.quantity--;

            if (existingItem.quantity <= 0)
            {
                cartItems.Remove(existingItem);
                Debug.Log($"���Ƴ�{goods.name}");
            }
            else 
            {
                Debug.Log($"{goods.name}������һ,ʣ��{existingItem.quantity}��");
            }

            RefreshCartUI();    //ˢ��UI
        }
    }

    public void DeleteGood(Goods goods)
    {
        cartItems.RemoveAll(item => item.goods.name == goods.name);
        Debug.Log($"��ɾ��{goods.name}");
        RefreshCartUI();    //ˢ��UI
    }

    public void ClearCart() 
    {
        cartItems.Clear();
        RefreshCartUI();    //ˢ��UI
        Debug.Log("��չ��ﳵ�ɹ�");
    }

    /*
    private void RefreshSingleCartItemUI(string goodsName)
    {
        foreach (CartItemUI ui in cartItemUIs)
        {
            ui.name = goodsName;
        }
        
    }
    */

    private void RefreshCartUI()            //ˢ�¹��ﳵҳ��
    {
        foreach (Transform child in cartContentParent)      
        {
            Destroy(child.gameObject);      //����������Ԥ����
        }

        foreach (CartItem item in cartItems)    
        {
            if (cartContentParent == null) 
            {
                Debug.LogError("û������");
                return;
            }

            GameObject cartItemObj = Instantiate(Good, cartContentParent);  //��ʵ����
            cartItemObj.name = item.goods.name;
            Debug.Log("���ɳɹ�");
            CartItemUI cartItemUI = cartItemObj.GetComponent<CartItemUI>(); //���뵽


            //Text itemText = cartItemObj.GetComponent<Text>();

            if (cartItemUI != null)
            {
                cartItemUI.SetData(item);
               
            }
            else
            {
                Debug.LogError("CartItemUI �ű�δ�ҵ���");
            }
        }

        UpdateTotalAndBadge();


    }

    private void UpdateTotalAndBadge()  //�����ܼۺͽǱ�
    {
        float total = 0;
        int totalQuantity = 0;

        foreach (CartItem item in cartItems) 
        {
            total += item.Subtotal;
            totalQuantity += item.quantity;
            

        }

        string totalPrize = total.ToString("F1");

        // �����ܼ���ʾ
        if (totalPriceText != null)
            totalPriceText.text = $"{totalPrize}";

        // ���¹��ﳵ�Ǳ�
        if (cartBadgeText != null)
        {   
            cartBadgeText.text = totalQuantity.ToString();
            if (totalQuantity > 0)
            {
                cartBadgeText.gameObject.SetActive(true);
                cartBadeg_Image.gameObject.SetActive(true);
            }
            else 
            {
                cartBadgeText.gameObject.SetActive(false);
                cartBadeg_Image.gameObject.SetActive(false);
            }
            
        }
    }
    public void Buy()
    {
        if (cartItems.Count > 0)    
        {
            uiManage.Pay_Panel.SetActive(true);
        }
        else    //���ﳵΪ�������
        {
            CartEmptyError_Image.gameObject.SetActive(true);
        }
    }

    public void Back()
    {
        uiManage.Pay_Panel.SetActive(false);
    }

    public void CartEmptyErrorOK() 
    {
        CartEmptyError_Image.gameObject.SetActive(false);
    }

    public void ConfirmPayment() 
    {
        if (AddressManage.Address == "Empty")
        {
            AddressEmptyError_Image.gameObject.SetActive(true);
        }
        else 
        {
            SuccessfulPurchase_Image.gameObject.SetActive(true);
        }
    }

    public void SuccessfulPurchaseOK() 
    {
        ClearCart();
        uiManage.SHOP_Panel.SetActive(true);
        uiManage.Cart_Panel.SetActive(false);
        uiManage.My_Panel.SetActive(false);
        uiManage.Pay_Panel.SetActive(false);
        SuccessfulPurchase_Image.gameObject.SetActive(false);
    }
}
