using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManage : MonoBehaviour
{
    public GameObject SHOP_Panel ;
    public GameObject Cart_Panel;
    public GameObject My_Panel;
    public GameObject Pay_Panel;

    public Button GoToChange_Button;



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    #region("����")  

    public void Button_SHOP() 
    {
        SHOP_Panel.SetActive(true);
        Cart_Panel.SetActive(false);
        My_Panel.SetActive(false);
        Pay_Panel.SetActive(false);
    }

    public void Button_Cart() 
    {
        SHOP_Panel.SetActive(false);
        Cart_Panel.SetActive(true);
        My_Panel.SetActive(false);
        Pay_Panel.SetActive(false);
    }

    public void Button_My() 
    {
        SHOP_Panel.SetActive(false);
        Cart_Panel.SetActive(false);
        My_Panel.SetActive(true);
        Pay_Panel.SetActive(false);
    }

    public void Button_GoTo() 
    {
        SHOP_Panel.SetActive(false);
        Cart_Panel.SetActive(false);
        My_Panel.SetActive(true);
        Pay_Panel.SetActive(false);
    }

    public void Exit()
    {
        Application.Quit();

        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;  // �༭����Ҳֹͣ
        #endif
    }




    #endregion
}
