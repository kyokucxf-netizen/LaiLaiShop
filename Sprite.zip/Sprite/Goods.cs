using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Goods 
{
    public string name;
    public float price;

    public Goods(string name, float price)
    {
        this.name = name;
        this.price = price;
    }
}
