using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class CartItem
{
    public Goods goods;     //��Ʒ��Ϣ
    public int quantity;    //����

    public CartItem(Goods goods) 
    {

    this.goods = goods;
    this.quantity = 1;

    }

    public float Subtotal => goods.price * quantity;

}

