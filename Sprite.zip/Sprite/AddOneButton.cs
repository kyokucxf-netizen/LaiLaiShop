using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AddOneButton : MonoBehaviour
{
    public Goods goods;
    private GameObject good;
    private Button button;

    // Start is called before the first frame update
    void Start()
    {
        button = GetComponent<Button>();
        good = this.gameObject;
        goods.name = good.name;
        

        if (button != null) 
        {
            button.onClick.AddListener(OnAddToCart);
        }


    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnAddToCart() 
    {
        if (goods != null)
        {   
            CartManager.Instance.AddToCart(goods);
        }
        else 
        {
            Debug.LogError("��Ʒδ����");        
        }
    }
}
