using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Timeline;
using UnityEngine.UI;

public class AddressManage : MonoBehaviour
{
    public Button AddressChange_Button;
    public Button Save_Button;
    public Button AddressEmptyErrorOK_Button;

    public TextMeshProUGUI Address_Text;    //My�����add
    public TMP_InputField AddressInput;     
    public TextMeshProUGUI Addresss_Text;   //���������ʾ��Add

    public GameObject My_Panel;
    public bool IsWait = false;

    public static string Address;

    public Image AddressEmptyError_Image;
    public Image Logo_Image;
    public Image Cheap_Image;


    public UIManage uiManage;  // ���� UIManage ����������л�   //new
    private Coroutine logoSpinCoroutine = null;     //new


    // Start is called before the first frame update
    void Start()
    {
        AddressEmptyError_Image.gameObject.SetActive(false);
        Save_Button.gameObject.SetActive(false);
        AddressInput.gameObject.SetActive(false);
        Address_Text.text = "Empty";
        Addresss_Text.text = "Empty";

        // ��������л��¼���ͨ�� UIManage��    //new
        if (uiManage != null)
        {
            // ���� UIManage �� OnPanelChanged �¼���ֱ����������
        }

    }

    // Update is called once per frame
    void Update()
    {
        /*
        if (My_Panel.activeSelf == true)
        {

            int RanRot_1 = Random.Range(0, 180);
            float scale_1 = 1 + Mathf.Sin(Time.time * 2) * 0.2f;
            Logo_Image.transform.Rotate(0, 0, -RanRot_1 * Time.deltaTime);
            Logo_Image.transform.localScale = new Vector3(scale_1, scale_1, 1);

            int RanRot_2 = Random.Range(90, 360);
            float scale_2 = -1 + Mathf.Sin(Time.time * 2) * 0.4f;
            Cheap_Image.transform.Rotate(0, 0, -RanRot_2 * Time.deltaTime);
            Cheap_Image.transform.localScale = new Vector3(scale_2, scale_2, 1);

        }
        */

        // ��ʽ1��ÿ֡��� My_Panel �Ƿ񱻼���      //new
        if (My_Panel.activeSelf)
        {
            // �����弤���ˣ���û���������е�Э�̣�������
            if (logoSpinCoroutine == null)
            {
                logoSpinCoroutine = StartCoroutine(StartLogoSpinWithDelay());
            }
        }
        else
        {
            // ���ر�ʱ��ֹͣЭ�̲�����
            if (logoSpinCoroutine != null)
            {
                StopCoroutine(logoSpinCoroutine);
                logoSpinCoroutine = null;
            }
        }

    }

    public void AddressChange() 
    {   
        AddressChange_Button.gameObject.SetActive(false);   //��ť���л���ʾ
        Save_Button.gameObject.SetActive(true);
        Address_Text.gameObject.SetActive(false);
        AddressInput.gameObject.SetActive(true);    
        
    }

    public void AddressSave() 
    {

        
        Address = AddressInput.text;
        if (!string.IsNullOrWhiteSpace(AddressInput.text) && AddressInput.text != "Empty")
        {   
            //�����ַ
            Address_Text.text = Address;
            Debug.Log($"��ַ�ѱ��棺{Address}");
            Addresss_Text.text = Address;
            Debug.Log($"�µ�����ַ�Ѹ��ģ�{Address}");

            //�л���ʾ
            AddressChange_Button.gameObject.SetActive(true);   //��ť���л���ʾ
            Save_Button.gameObject.SetActive(false);
            Address_Text.gameObject.SetActive(true);        //�ı�������л���ʾ
            AddressInput.gameObject.SetActive(false);

        }
        else 
        {
            AddressEmptyError_Image.gameObject.SetActive(true);
            Debug.LogError("��ַ����Ϊ��");
        }
    }

    public void closeAddressEmptyError() 
    {
        AddressEmptyError_Image.gameObject.SetActive(false);
    }



    //Э��        //new
    IEnumerator StartLogoSpinWithDelay()
    {
        // �ȴ� 5 ��
        yield return new WaitForSeconds(5f);

        // 5 ���ʼ��ת
        while (My_Panel.activeSelf)  // ֻҪ��廹���žͼ���ת
        {
            int RanRot_1 = Random.Range(0, 180);
            float scale_1 = 1 + Mathf.Sin(Time.time * 2) * 0.2f;
            Logo_Image.transform.Rotate(0, 0, -RanRot_1 * Time.deltaTime);
            Logo_Image.transform.localScale = new Vector3(scale_1, scale_1, 1);

            int RanRot_2 = Random.Range(90, 360);
            float scale_2 = -1 + Mathf.Sin(Time.time * 2) * 0.4f;
            Cheap_Image.transform.Rotate(0, 0, -RanRot_2 * Time.deltaTime);
            Cheap_Image.transform.localScale = new Vector3(scale_2, scale_2, 1);
            yield return null;  // �ȴ���һ֡
        }

        logoSpinCoroutine = null;
    }
}
