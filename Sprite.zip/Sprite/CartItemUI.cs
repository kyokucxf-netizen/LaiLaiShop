using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CartItemUI : MonoBehaviour
{
    public Button AddOne_Button;
    public Button DeleteItem_Button;
    public Button RemoveOne_Button;
    public TextMeshProUGUI Quantity_Text;
    public TextMeshProUGUI ItemName_Text;
    public CartItem cartItemData;
    public Image itemImage;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void RefreshDisplay() 
    {
        if (cartItemData == null) return;
        {

            if (ItemName_Text != null) 
            {
                ItemName_Text.text = cartItemData.goods.name;
            }

            if (Quantity_Text != null) 
            {
                Quantity_Text.text = cartItemData.quantity.ToString();
            }
            Debug.Log("RefreshDisplayִ�гɹ�");

            
        }

        LoadItemImage(cartItemData.goods.name);

            Debug.Log("ͼƬ���سɹ�");
        
    }

    #region(��ť)
    public void AddOne() 
    {
        CartManager.Instance.AddToCart(cartItemData.goods);
    }
    public void RemoveOne() 
    {
        CartManager.Instance.RemoveFromCart(cartItemData.goods);
    }
    public void DeleteItem() 
    {
        CartManager.Instance.DeleteGood(cartItemData.goods);
    }

    #endregion

    public void SetData(CartItem item) 
    {
        cartItemData = item;
        Debug.Log("cartItemData ��ֵ��item�ɹ�");
        RefreshDisplay();
    }

    private void LoadItemImage(string itemName)     //����ͼƬ
    {
        if (itemImage != null) 
        {
            Sprite loadedSprite = Resources.Load<Sprite>(itemName);

            if (loadedSprite != null)
            {
                itemImage.sprite = loadedSprite;
            }
            else 
            {
                Debug.LogWarning($"δ�ҵ�ͼƬ��{itemName}");
            }
        }
    }

}
